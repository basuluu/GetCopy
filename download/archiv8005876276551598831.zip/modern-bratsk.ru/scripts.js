var _tmpl_viewMode = 'grid', // 'grid' or 'list'
    _tmpl_newDays = 7;


if (navigator.userAgent.match(/Android/i) ||
    navigator.userAgent.match(/webOS/i) ||
    navigator.userAgent.match(/iPhone/i) ||
    navigator.userAgent.match(/iPad/i) ||
    navigator.userAgent.match(/iPod/i) ||
    navigator.userAgent.match(/IEMobile/i) ||
    navigator.userAgent.match(/BlackBerry/i)) {
    _tmpl_isMobile = true;
};


window.onload = function() {
    _func_loader();

    _func_goTop();
    _func_goodsViewMode();
    _func_toBasket();
    _func_goodTabs();
    _func_blogEntries();
    _func_photoEntries();
    _func_newGood();


    $('#shop-basket').on({
        click: function() {
            $(this).addClass('opened');
        },
        mouseleave: function() {
            $(this).removeClass('opened');
        }
    });

    $('#nav .uMenuRoot > li.uWithSubmenu > a').append('<i class="fa fa-angle-down"></i>');
    $('#nav .uMenuRoot > li > ul li.uWithSubmenu > a').append('<i class="fa fa-angle-right"></i>');

    $("#slider").aSlider({
        prevBtn: '#slider-wrap .fa-angle-left',
        nextBtn: '#slider-wrap .fa-angle-right',
        fadeSpeed: 500,
        autoPlay: true,
        autoPlayDelay: 4000
    });


    $('<tr><td class="catsTd"><a href="/photo" class="catName">Все</a></td></tr>').prependTo('.ph_cats .catsTable');


    $(document.body).on('appear', '.count-val', function(e, $affected) {
        var c = $(this).data('count');
        if ($(this).is(':appeared') && !$(this).hasClass('starting')) {
            $(this).addClass('starting');
            $(this).countTo({
                from: 0,
                to: c
            });
        }
    });
    $('.count-val').appear({
        force_process: true
    });

    $('.menu-icon').click(function() {
        $('#nav .uMenuV').toggle(300);
    });


    

    $('.gp_tabs').aTabs();

	$('#qv_close, #qv_overlay').click(function() {
	$('#qv_container').fadeOut(300);
	    setTimeout(function() {
	        $('#gp_link_css').remove();
	    }, 300);
	    $('#qv_window #qv_content').remove();
    });
    

    $('.b_cats .cat-blocks ul').each(function() {
        var a = $(this).find('li');
        if ( a.length > 0 ) {
            $(this).prev().addClass('arrow');
        } 
    });

    $('<button id="qv_more_button" title="Перейти на страницу товара">Подробности</button>').appendTo('#qv_container');

};


function _quickView(a) {
    var link = a.getAttribute("data-link");
    $('<style id="gp_link_css">.small {display: none;}</style>').appendTo('body');
    $('#qv_container').fadeIn(300);
    $('#qv_window').load('' + link + ' #qv_content');
    $('#qv_more_button').click(function(){
        location.href = link;
    });
};


function _func_loader() {
    $("#loader").fadeOut(500);
};

function _func_goTop() {
    $('<span id="go-top" class="fa fa-angle-up" title="Вверх!"></span>').appendTo('body');
    $('#go-top').css({
        'opacity': '0',
        'visibility': 'hidden'
    });
    $(window).scroll(function() {
        if ($(this).scrollTop() > 500) {
            $('#go-top').css({
                'opacity': '1',
                'visibility': 'visible'
            });
        } else {
            $('#go-top').css({
                'opacity': '0',
                'visibility': 'hidden'
            });
        }
    });
    $('#go-top').click(function() {
        $('body,html').animate({
            scrollTop: 0
        }, 800);
        return false
    });
};

function _func_goodsViewMode() {


    switch (getCookie('itemViewMode')) {
        case 'grid':
            $('.goods-view-mode-grid').addClass('goods-view-mode-active');
            $('#content #goods_cont').removeClass('list-item-view-mode-list');
            break
        case 'list':
            $('.goods-view-mode-list').addClass('goods-view-mode-active');
            $('#content #goods_cont').addClass('list-item-view-mode-list');
            break
        case undefined:
            setCookie('itemViewMode', _tmpl_viewMode);
            switch (getCookie('itemViewMode')) {
                case 'grid':
                    $('.goods-view-mode-grid').addClass('goods-view-mode-active');
                    $('#content #goods_cont').removeClass('list-item-view-mode-list');
                    break
                case 'list':
                    $('.goods-view-mode-list').addClass('goods-view-mode-active');
                    $('#content #goods_cont').addClass('list-item-view-mode-list');
                    break
                default:
                    alert('ERROR!\ninvalid _tmpl_viewMode: "' + _tmpl_viewMode + '"');
            };
            break
        default:
            alert('ERROR!\ninvalid _tmpl_viewMode: "' + _tmpl_viewMode + '"');
    };

    $('.goods-view-mode > span').click(function() {
        if ($(this).hasClass('goods-view-mode-active')) {
            return false;
        } else {
            $('.goods-view-mode > span').removeClass('goods-view-mode-active');
            $(this).addClass('goods-view-mode-active');
            if ($(this).hasClass('goods-view-mode-grid')) {
                setCookie('itemViewMode', 'grid');
                $('#content #goods_cont').removeClass('list-item-view-mode-list');
            } else if ($(this).hasClass('goods-view-mode-list')) {
                setCookie('itemViewMode', 'list');
                $('#content #goods_cont').addClass('list-item-view-mode-list');
            }
        }
    });

};

function _func_newGood() {
    if (typeof _ucoz_date != 'undefined') { c_date = new Date(_ucoz_date.replace(/(\d+).(\d+).(\d+)/, '$3/$2/$1')); }
    $('.gnew').each(function() {
        g_date = new Date($(this).data('date').replace(/(\d+).(\d+).(\d+)/, '$3/$2/$1'));
        n_date = Math.floor((c_date - g_date) / (1000 * 60 * 60 * 24));
        if (n_date <= _tmpl_newDays) {
            $(this).css('display', 'block');
        };
    });
};

function _func_toBasket() {
    $('.gp_buttons input[type="text"]').before('<span class="fa fa-minus"></span>');
    $('.gp_buttons input[type="text"]').after('<span class="fa fa-plus"></span>');

    $('.gp_buttons .fa-plus').click(function() {
        var inputVal = +$('.gp_buttons input[type="text"]').val();
        $('.gp_buttons input[type="text"]').val(inputVal + 1)
    });
    $('.gp_buttons .fa-minus').click(function() {
        var inputVal = +$('.gp_buttons input[type="text"]').val();
        if (inputVal > 1) {
            $('.gp_buttons input[type="text"]').val(inputVal - 1)
        }
    });
};

function _func_goodTabs() {
    $('#tabs').aTabs();
};

function _func_blogEntries() {
    $('.post').parent().addClass('post-wrap col2').parent().addClass('oh');
};

function _func_photoEntries() {
    $('.photo').parent().removeAttr('id').removeAttr('class').removeAttr('style').parent().removeAttr('id').removeAttr('class').removeAttr('style').addClass('photo-wrap col4').parent().removeAttr('id').removeAttr('class').removeAttr('style').addClass('photo-list');
};

function setCookie(name, value, options) {
    options = options || {};
    var expires = options.expires;
    if (typeof expires == "number" && expires) {
        var d = new Date();
        d.setTime(d.getTime() + expires * 1000);
        expires = options.expires = d;
    }
    if (expires && expires.toUTCString) {
        options.expires = expires.toUTCString();
    }
    value = encodeURIComponent(value);
    var updatedCookie = name + "=" + value;
    for (var propName in options) {
        updatedCookie += "; " + propName;
        var propValue = options[propName];
        if (propValue !== true) {
            updatedCookie += "=" + propValue;
        }
    }
    document.cookie = updatedCookie;
};

function getCookie(name) {
    var matches = document.cookie.match(new RegExp(
        "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
};

function deleteCookie(name) {
    setCookie(name, "", {
        expires: -1
    });
};